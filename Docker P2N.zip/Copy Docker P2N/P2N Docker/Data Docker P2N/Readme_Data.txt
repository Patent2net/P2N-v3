--------------------       Extract Results from Docker P2N         ---------------------
You have the possibility to extract DATA results from Docker P2N :

* To Extract :
	1- Go in "Data Docker P2N" folder
	2- Click on "Extract_Data_P2N.bat" if Docker P2N already done research, a folder named "DATA" will appear. 
		It contain all the content you can see in docker P2N.