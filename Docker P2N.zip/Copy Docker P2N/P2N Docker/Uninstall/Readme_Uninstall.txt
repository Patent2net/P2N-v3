* To Uninstall :
	1- Run "Stop_P2N.bat".
	2- then go in uninstall folder and execute "Uninstall_P2N.bat"
	3- you can now delete docker or do another installation of P2N