--------------------       Modify Cles-epo.txt         ---------------------

if you need to modify your "Cles-epo.txt" in Docker P2N :

* To add / replace a "Cles-epo.txt" in Docker P2N :

	1- Modify (or replace if you already have one) the "Cles-epo.txt" file you see in the folder.
	2- Click on "Replace_Epo_P2N.bat"
	3- The file is now in docker P2N


* To Delete a "Cles-epo.txt" in Docker P2N :
	1- Click on "Delete_Epo_P2N.bat"
	2- Docker P2N now don't have any "Cles-epo.txt". don't forget that this file is essential to the proper functioning of docker


* To copy and extract a "Cles-epo.txt" from Docker P2N :
	1- go in "Extract Epo" folder
	2- click on "Extract_Epo_P2N.bat"
	3- the file will appear in the same folder.
		- The file is still present in Docker P2N
		- Each time you will use "Extract_Epo_P2N.bat" if any "Cles-Epo.txt" is already present in the folder, he will be overwritted
