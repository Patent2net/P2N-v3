To install the Docker version of P2N:

1- Download and install docker : https://docs.docker.com/get-docker/
2- Update the file cles-epo.txt with your credentials (if you don't have it follow the instructions who can be found here :
http://patent2netv2.vlab4u.info/dokuwiki/doku.php?id=user_manual:download_install#register_the_use_of_p2n )
3- Click on "Run_P2N.bat", the installation will take some time. The window will automatically close at the end of the install.
4- After the installation, P2N will automatically start. To access it,on your web browser go at 127.0.0.1:5000


To Stop P2N :
1- Simply click on "Stop_P2N.bat"


To start P2N:
1- Click on "Run_P2N.bat"
2- on your web browser go at 127.0.0.1:5000

If you want instead see all the research you done, go at 127.0.0.1:5000/index

To Uninstall :
1- Run "Stop_P2N.bat".
2- then go in uninstall folder and execute "Uninstall_P2N.bat"
3- you can now delete docker or do another installation of P2N

