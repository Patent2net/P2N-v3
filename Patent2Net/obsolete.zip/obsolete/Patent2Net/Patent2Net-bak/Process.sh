python OPSGatherPatentsv2.py $@
python OPSGatherAugment-Families.py $@

python FormateExportAttractivityCartography.py $@
python FormateExportBiblio.py $@
python FormateExportCountryCartography.py $@

python FormateExportDataTableFamilies.py $@
python FormateExportDataTable.py $@
python FormateExportPivotTable.py $@

python OPSGatherContentsV2-Iramuteq.py $@
python OPSGatherContentsV2-Images.py $@
python P2N-FreePlane.py $@
python FusionCarrot2.py $@
python FusionImages.py $@
python FusionIramuteq2.py $@
python P2N-PreNetworks.py CountryCrossTech $@
python P2N-PreNetworks.py CrossTech $@
python P2N-PreNetworks.py InventorsCrossTech $@
python P2N-PreNetworks.py Applicants_CrossTech $@
python P2N-PreNetworks.py Inventors $@
python P2N-PreNetworks.py ApplicantInventor $@
python P2N-PreNetworks.py Applicants $@
python P2N-PreNetworks.py References $@
python P2N-PreNetworks.py Citations $@
python P2N-PreNetworks.py Equivalents $@

python P2N-Networks.py CountryCrossTech $@
python P2N-Networks.py CrossTech $@
python P2N-Networks.py InventorsCrossTech $@
python P2N-Networks.py Applicants_CrossTech $@
python P2N-Networks.py Inventors $@
python P2N-Networks.py ApplicantInventor $@
python P2N-Networks.py Applicants $@
python P2N-Networks.py References $@
python P2N-Networks.py Citations $@
python P2N-Networks.py Equivalents $@

python P2N-NetworksJS.py CountryCrossTech $@
python P2N-NetworksJS.py CrossTech $@
python P2N-NetworksJS.py InventorsCrossTech $@
python P2N-NetworksJS.py Applicants_CrossTech $@
python P2N-NetworksJS.py Inventors $@
python P2N-NetworksJS.py ApplicantInventor $@
python P2N-NetworksJS.py Applicants $@
python P2N-NetworksJS.py References $@
python P2N-NetworksJS.py Citations $@
python P2N-NetworksJS.py Equivalents $@
python Interface2.py $@
